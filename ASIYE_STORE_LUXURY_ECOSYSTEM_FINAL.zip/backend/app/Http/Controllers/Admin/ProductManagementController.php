<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductManagementController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
        $this->middleware('permission:manage-products');
    }

    public function index()
    {
        $products = Product::with(['brand', 'category'])->paginate(20);
        return response()->json($products);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name_fa' => 'required|string',
            'brand_id' => 'required|exists:brands,id',
            'category_id' => 'required|exists:categories,id',
            'original_price' => 'required|numeric|min:0',
            'sale_price' => 'required|numeric|min:0',
            'sku' => 'required|unique:products,sku',
        ]);

        $product = Product::create($request->all());

        // Handle images and variants (logic to be added)

        return response()->json($product, 201);
    }

    public function update(Request $request, $id)
    {
        $product = Product::findOrFail($id);
        $request->validate([
            'name_fa' => 'required|string',
            'sku' => 'required|unique:products,sku,' . $id,
        ]);

        $product->update($request->all());
        return response()->json($product);
    }

    public function destroy($id)
    {
        $product = Product::findOrFail($id);
        // Check financial history before deletion (logic to be added)
        $product->delete();
        return response()->json(['message' => 'محصول با موفقیت حذف شد']);
    }
}
