<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;

class OrderStatusController extends Controller
{
    public function updateStatus(Request $request, $orderId)
    {
        // Only Admin or System Callback
        $order = Order::findOrFail($orderId);
        
        $request->validate([
            'status' => 'required|in:pending_payment,paid,confirmed,preparing,ready_to_ship,shipped,delivered,cancelled,returned,refunded',
            'admin_id' => 'nullable|exists:users,id',
            'notes' => 'nullable|string',
        ]);

        // Transaction Log
        $order->status = $request->status;
        $order->save();

        $order->histories()->create([
            'status' => $request->status,
            'admin_id' => $request->admin_id,
            'notes' => $request->notes,
        ]);

        // Trigger Notifications (SMS/Firebase)
        // NotificationService::send($order);

        return response()->json($order);
    }

    public function track(Request $request, $orderId)
    {
        $order = Order::with(['items.variant.product', 'shipping', 'payment'])
                      ->where('customer_id', auth()->user()->customer->id)
                      ->findOrFail($orderId);

        return response()->json($order);
    }
}
