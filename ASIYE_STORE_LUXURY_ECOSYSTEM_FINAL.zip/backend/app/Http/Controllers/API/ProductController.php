<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $query = Product::with(['brand', 'category', 'variants', 'images'])
                        ->where('published', true);

        // Filters
        if ($request->has('category')) {
            $query->where('category_id', $request->category);
        }
        if ($request->has('brand')) {
            $query->where('brand_id', $request->brand);
        }
        if ($request->has('search')) {
            $query->where('name_fa', 'like', '%' . $request->search . '%');
        }

        // Sorting
        $sortBy = $request->input('sort_by', 'created_at');
        $direction = $request->input('direction', 'desc');
        $query->orderBy($sortBy, $direction);

        return response()->json($query->paginate(15));
    }

    public function show($id)
    {
        $product = Product::with(['brand', 'category', 'variants', 'images'])
                          ->where('published', true)
                          ->findOrFail($id);

        return response()->json($product);
    }
}
