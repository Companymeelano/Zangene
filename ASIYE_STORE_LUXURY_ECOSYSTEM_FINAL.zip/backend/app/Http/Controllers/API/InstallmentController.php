<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\InstallmentOrder;
use Illuminate\Http\Request;

class InstallmentController extends Controller
{
    // Snapp Pay & Tara Adapter Logic
    public function createRequest(Request $request)
    {
        $request->validate([
            'order_id' => 'required|exists:orders,id',
            'provider' => 'required|in:snapp_pay,tara',
            'installments' => 'required|integer',
        ]);

        $order = auth()->user()->customer->orders()->findOrFail($request->order_id);

        // Check if provider is active (Contract status)
        // $provider = InstallmentProvider::where('slug', $request->provider)->first();
        // if (!$provider->is_active) return response()->json(['error' => 'سرویس در حال حاضر غیرفعال است.'], 403);

        // Create Installment Order Record (Sandbox/Pending)
        $installmentOrder = InstallmentOrder::create([
            'order_id' => $order->id,
            'provider' => $request->provider,
            'amount' => $order->total_amount,
            'status' => 'pending',
        ]);

        // In real scenario: redirect to provider URL
        // $redirectUrl = InstallmentAdapter::initiate($installmentOrder);

        return response()->json([
            'installment_order_id' => $installmentOrder->id,
            'status' => 'pending',
            'message' => 'درخواست اقساطی ثبت شد. در انتظار تایید سرویس.',
            // 'redirect_url' => $redirectUrl,
        ]);
    }

    public function callback(Request $request, $provider)
    {
        // Logic to verify callback from Snapp Pay or Tara
        // $result = InstallmentAdapter::verify($request->all());
        
        // Update InstallmentOrder and Order Status
        // $installmentOrder->update(['status' => 'approved', 'transaction_id' => $result->id]);
        // $order->update(['status' => 'paid']);

        return response()->json(['status' => 'success', 'message' => 'تایید تراکنش اقساطی']);
    }
}
