<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\Customer;

class AuthController extends Controller
{
    // Customer Login via Mobile OTP
    public function sendOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'mobile' => 'required|string|size:11',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        $user = User::firstOrCreate(
            ['mobile' => $request->mobile],
            ['name' => 'مشتری جدید', 'role_id' => null] // Role will be customer
        );

        // Generate and send OTP (SMS Adapter)
        // $otp = rand(100000, 999999);
        // SMSAdapter::send($request->mobile, "کد تایید ASIYE STORE: " . $otp);

        // Store OTP in Cache/Database (Logic to be added)

        return response()->json([
            'message' => 'کد تایید به شماره موبایل شما ارسال شد.',
            'user_id' => $user->id,
        ]);
    }

    public function verifyOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'mobile' => 'required|string|size:11',
            'otp' => 'required|string|size:6',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        $user = User::where('mobile', $request->mobile)->first();
        
        // Verify OTP (Logic to be added)
        // if ($otp !== Cache::get('otp_' . $request->mobile)) return response()->json(['error' => 'کد اشتباه است.'], 401);

        // Ensure Customer exists
        if (!$user->customer) {
            Customer::create(['user_id' => $user->id]);
        }

        // Generate Token (JWT or Sanctum)
        $token = $user->createToken('ASIYE_STORE_CUSTOMER')->plainTextToken;

        return response()->json([
            'access_token' => $token,
            'token_type' => 'Bearer',
            'user' => $user,
        ]);
    }

    // Admin Login (RBAC)
    public function adminLogin(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'mobile_or_email' => 'required',
            'password' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        // Logic for Admin authentication and RBAC check
        // ...

        return response()->json(['message' => 'ورود موفقیت‌آمیز']);
    }
}
