<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\ProductVariant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CheckoutController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:customer');
    }

    public function processCheckout(Request $request)
    {
        $request->validate([
            'items' => 'required|array', // ['variant_id' => 1, 'quantity' => 2]
            'address_id' => 'required|exists:customer_addresses,id',
            'shipping_method_id' => 'required|exists:shipping_methods,id',
            'payment_gateway_id' => 'required|exists:payment_gateways,id',
            'coupon_code' => 'nullable|string',
        ]);

        // Start Transaction
        DB::beginTransaction();

        try {
            // 1. Calculate total and check inventory (Server-side only)
            $totalAmount = 0;
            $itemsData = [];

            foreach ($request->items as $item) {
                $variant = ProductVariant::findOrFail($item['variant_id']);
                $inventory = $variant->inventory;

                if ($inventory->quantity < $item['quantity']) {
                    throw new \Exception("موجودی کافی برای تنوع انتخاب شده وجود ندارد.");
                }

                $price = $variant->product->sale_price + $variant->price_offset;
                $totalAmount += $price * $item['quantity'];

                $itemsData[] = [
                    'product_variant_id' => $variant->id,
                    'quantity' => $item['quantity'],
                    'price_at_purchase' => $price,
                ];

                // Reduce inventory immediately (Atomic)
                $inventory->decrement('quantity', $item['quantity']);
            }

            // 2. Apply Coupon (Logic to be added)
            // $totalAmount -= $discount;

            // 3. Create Order
            $order = auth()->user()->customer->orders()->create([
                'address_id' => $request->address_id,
                'total_amount' => $totalAmount,
                'shipping_cost' => 0, // Calculate based on method
                'payment_method' => $request->payment_gateway_id,
                'shipping_method' => $request->shipping_method_id,
                'status' => 'pending_payment',
            ]);

            // 4. Create Order Items
            foreach ($itemsData as $data) {
                $order->items()->create($data);
            }

            // 5. Create Payment Request (Adapter logic)
            // $paymentUrl = PaymentAdapter::createTransaction($order);

            DB::commit();

            return response()->json([
                'order_id' => $order->id,
                'message' => 'سفارش ثبت شد. در حال هدایت به درگاه پرداخت...',
                // 'payment_url' => $paymentUrl,
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['error' => $e->getMessage()], 422);
        }
    }
}
