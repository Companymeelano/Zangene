<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureTransactionSafety
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next): Response
    {
        // ASIYE STORE - SECURITY MIDDLEWARE
        // Ensures sensitive operations (Orders, Inventory, Payments)
        // are logged and verified for RBAC/Customer identity.

        $path = $request->path();
        
        // Log sensitive operations
        if (str_starts_with($path, 'api/v1/admin') || str_starts_with($path, 'api/v1/checkout')) {
            \App\Models\AdminActivityLog::create([
                'admin_id' => auth()->id() ?? null, // For admin
                'action' => $request->method() . ' ' . $path,
                'details' => json_encode($request->except(['password', 'otp'])),
                'ip_address' => $request->ip(),
            ]);
        }

        return $next($request);
    }
}
