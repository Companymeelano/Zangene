<?php

// ASIYE STORE - API ROUTES (Customer & Public)
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\ProductController;
use App\Http\Controllers\API\AuthController;
use App\Http\Controllers\API\OrderStatusController;
use App\Http\Controllers\API\InstallmentController;

// Public Routes
Route::prefix('v1')->group(function () {
    // Auth
    Route::post('/auth/send-otp', [AuthController::class, 'sendOtp']);
    Route::post('/auth/verify-otp', [AuthController::class, 'verifyOtp']);

    // Products
    Route::get('/products', [ProductController::class, 'index']);
    Route::get('/products/{id}', [ProductController::class, 'show']);

    // Installment (Sandbox/Public)
    Route::post('/installment/request', [InstallmentController::class, 'createRequest']);
    Route::post('/installment/callback/{provider}', [InstallmentController::class, 'callback']);

    // Order Tracking (Customer)
    Route::middleware('auth:customer')->group(function () {
        Route::get('/orders/track/{orderId}', [OrderStatusController::class, 'track']);
        Route::post('/checkout', [\App\Http\Controllers\Customer\CheckoutController::class, 'processCheckout']);
    });
});

// Admin Routes (Protected by RBAC)
Route::prefix('v1/admin')->middleware(['auth:admin', 'role:super-admin|store-manager'])->group(function () {
    // Product Management
    Route::get('/products', [\App\Http\Controllers\Admin\ProductManagementController::class, 'index']);
    Route::post('/products', [\App\Http\Controllers\Admin\ProductManagementController::class, 'store']);
    Route::put('/products/{id}', [\App\Http\Controllers\Admin\ProductManagementController::class, 'update']);
    Route::delete('/products/{id}', [\App\Http\Controllers\Admin\ProductManagementController::class, 'destroy']);

    // Order Management (Status Update)
    Route::post('/orders/{id}/status', [OrderStatusController::class, 'updateStatus']);

    // Dashboard Stats (Logic to be added)
    Route::get('/dashboard/stats', [\App\Http\Controllers\Admin\DashboardController::class, 'stats']);
});
