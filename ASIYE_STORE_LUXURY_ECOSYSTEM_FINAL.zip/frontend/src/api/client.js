/* ASIYE STORE - API INTEGRATION (Customer Website) */
/* Connects Frontend HTML/CSS to Laravel Backend API */

class ASIYE_API {
    constructor() {
        this.baseUrl = '/api/v1'; // Relative to sandbox root
        this.token = localStorage.getItem('asiye_token');
    }

    async getProducts(filters = {}) {
        const params = new URLSearchParams(filters);
        const response = await fetch(`${this.baseUrl}/products?${params}`);
        return response.json();
    }

    async addToCart(variantId, quantity) {
        const response = await fetch(`${this.baseUrl}/cart/add`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${this.token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ variant_id: variantId, quantity })
        });
        return response.json();
    }

    async checkout(items, addressId, shippingId, gatewayId) {
        const response = await fetch(`${this.baseUrl}/checkout`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${this.token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ items, address_id: addressId, shipping_method_id: shippingId, payment_gateway_id: gatewayId })
        });
        return response.json();
    }
}

// Initialize and render products
const api = new ASIYE_API();

async function renderHomeProducts() {
    const grid = document.getElementById('product-grid');
    if (!grid) return;

    try {
        const data = await api.getProducts({ sort_by: 'created_at', direction: 'desc' });
        grid.innerHTML = ''; // Clear placeholder
        
        data.data.forEach(product => {
            const card = document.createElement('div');
            card.className = 'product-card';
            card.innerHTML = `
                <img src="${product.images[0]?.path || '/images/logo_vertical_icon_luxury.png'}" alt="${product.name_fa}" class="product-image">
                <div class="product-info">
                    <div class="product-title" style="font-family: 'IRANYekan', sans-serif;">${product.name_fa}</div>
                    <div class="product-price" style="font-family: 'IRANYekan', sans-serif;">${product.sale_price.toLocaleString()} تومان</div>
                    <button class="btn-luxury" style="width: 100%; margin-top: 1rem;" onclick="api.addToCart(${product.variants[0].id}, 1)">افزودن به سبد</button>
                </div>
            `;
            grid.appendChild(card);
        });
    } catch (error) {
        console.error("Error loading products:", error);
    }
}

// Run on load
document.addEventListener('DOMContentLoaded', renderHomeProducts);
