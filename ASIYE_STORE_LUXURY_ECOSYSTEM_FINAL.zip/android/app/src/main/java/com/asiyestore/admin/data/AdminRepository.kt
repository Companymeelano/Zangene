package com.asiyestore.admin.data

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

// Model for Dashboard Stats
data class DashboardStats(
    val totalSalesToday: Long = 0,
    val newOrdersCount: Int = 0,
    val lowInventoryCount: Int = 0,
    val newCustomersCount: Int = 0
)

// Repository Pattern
class AdminRepository(private val apiService: ApiService) {
    fun getDashboardStats(): StateFlow<DashboardStats> {
        // Implementation using Retrofit/OkHttp
        // return apiService.getStats().stateIn(...)
        return MutableStateFlow(DashboardStats()).asStateFlow()
    }

    fun getProducts(): StateFlow<List<ProductModel>> {
        // Implementation
        return MutableStateFlow(emptyList()).asStateFlow()
    }
}

// ViewModel (MVVM)
class DashboardViewModel(private val repository: AdminRepository) : ViewModel() {
    val stats = repository.getDashboardStats()
    val products = repository.getProducts()

    fun refreshStats() {
        // Logic to refresh data
    }
}

// Data Models
data class ProductModel(
    val id: Long,
    val nameFa: String,
    val salePrice: Long,
    val originalPrice: Long,
    val sku: String,
    val imageUrl: String,
    val inventory: Int
)

// Clean Architecture: Interface for API Service
interface ApiService {
    // suspend fun getStats(): DashboardStats
    // suspend fun getProducts(): List<ProductModel>
}
