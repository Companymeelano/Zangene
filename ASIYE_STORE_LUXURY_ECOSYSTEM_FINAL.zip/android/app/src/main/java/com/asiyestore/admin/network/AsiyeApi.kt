package com.asiyestore.admin.network

import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Body

// ASIYE STORE - API INTERFACE (Kotlin/Retrofit)
interface AsiyeApi {
    // Customer/Public
    @GET("v1/products")
    suspend fun getProducts(@Header("Authorization") token: String? = null): ProductResponse

    // Admin (RBAC)
    @GET("v1/admin/dashboard/stats")
    suspend fun getAdminStats(@Header("Authorization") token: String): DashboardStatsResponse

    @POST("v1/admin/products")
    suspend fun createProduct(@Header("Authorization") token: String, @Body request: CreateProductRequest): ProductModel

    // Checkout (Atomic Transaction)
    @POST("v1/checkout")
    suspend fun processCheckout(@Header("Authorization") token: String, @Body request: CheckoutRequest): CheckoutResponse

    // Installment (Snapp Pay / Tara Sandbox)
    @POST("v1/installment/request")
    suspend fun requestInstallment(@Header("Authorization") token: String, @Body request: InstallmentRequest): InstallmentResponse
}

// Data Classes for JSON Mapping
data class ProductResponse(val data: List<ProductModel>, val current_page: Int, val total: Int)
data class DashboardStatsResponse(val total_sales_today: Long, val new_orders_count: Int, val low_inventory_count: Int, val new_customers_count: Int)
data class CreateProductRequest(val name_fa: String, val brand_id: Long, val category_id: Long, val original_price: Double, val sale_price: Double, val sku: String)
data class CheckoutRequest(val items: List<OrderItem>, val address_id: Long, val shipping_method_id: Long, val payment_gateway_id: Long)
data class InstallmentRequest(val order_id: Long, val provider: String, val installments: Int)

// Response Wrappers
data class ProductModel(val id: Long, val name_fa: String, val sale_price: Double, val original_price: Double, val sku: String, val images: List<String>, val inventory: Int)
data class OrderItem(val variant_id: Long, val quantity: Int)
data class CheckoutResponse(val order_id: Long, val message: String, val payment_url: String?)
data class InstallmentResponse(val installment_order_id: Long, val status: String, val redirect_url: String?)
