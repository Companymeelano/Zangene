package com.asiyestore.admin.ui.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.asiyestore.admin.data.DashboardStats
import com.asiyestore.admin.data.ProductModel

// Luxury Color Palette (Jetpack Compose)
val ChampagneGold = Color(0xFFC6A16C)
val SoftGold = Color(0xFFD8BB8B)
val Ivory = Color(0xFFF8F6F1)
val WarmWhite = Color(0xFFFFFFFF)
val DeepCharcoal = Color(0xFF242321)
val LuxuryBlack = Color(0xFF171717)
val RoseBeige = Color(0xFFE8D8CE)
val PlatinumGray = Color(0xFFB9B6B0)

@Composable
fun AdminDashboardScreen(viewModel: DashboardViewModel = viewModel()) {
    val stats by viewModel.stats.collectAsState()
    val products by viewModel.products.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Ivory)
    ) {
        // Header
        TopAppBar(
            colors = TopAppBarDefaults.topAppBarColors(containerColor = LuxuryBlack, titleContentColor = WarmWhite),
            title = { Text("داشبورد مدیریت ASIYE STORE", fontWeight = FontWeight.Bold) },
            actions = {
                Icon(
                    painter = painterResource(id = R.drawable.ic_notification), // SVG Icon
                    contentDescription = "اعلانات",
                    tint = ChampagneGold
                )
            }
        )

        // Stats Grid
        LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    StatCard(title = "فروش امروز", value = "${stats.totalSalesToday} تومان", color = ChampagneGold)
                    StatCard(title = "سفارش‌های جدید", value = "${stats.newOrdersCount}", color = SoftGold)
                    StatCard(title = "موجودی کم", value = "${stats.lowInventoryCount}", color = RoseBeige)
                    StatCard(title = "مشتریان جدید", value = "${stats.newCustomersCount}", color = PlatinumGray)
                }
            }

            // Products List
            item {
                Text("محصولات", style = MaterialTheme.typography.headlineMedium, color = DeepCharcoal, modifier = Modifier.padding(vertical = 16.dp))
                items(products) { product ->
                    ProductCard(product = product)
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, color: Color) {
    Card(
        modifier = Modifier.fillMaxWidth().weight(1f).padding(8.dp),
        colors = CardDefaults.cardColors(containerColor = WarmWhite),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, PlatinumGray)
    ) {
        Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = title, color = PlatinumGray, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = value, color = DeepCharcoal, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Box(modifier = Modifier.size(4.dp).background(color).padding(2.dp))
        }
    }
}

@Composable
fun ProductCard(product: ProductModel) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = WarmWhite),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column {
            Image(
                painter = painterResource(id = R.drawable.ic_product_placeholder), // Placeholder
                contentDescription = product.nameFa,
                modifier = Modifier.fillMaxWidth().height(120.dp),
                contentScale = androidx.compose.ui.graphics.ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = product.nameFa, color = DeepCharcoal, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp))
            Text(text = "${product.salePrice} تومان", color = ChampagneGold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
            Text(text = "موجودی: ${product.inventory}", color = PlatinumGray, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp))
        }
    }
}
